﻿var g_ContentsURL = "KFS%205_0_2%20Test-toc.htm";
var g_IndexURL = "KFS%205_0_2%20Test-index.htm";
var g_SearchURL = "KFS%205_0_2%20Test-search.htm";
var g_FavoritesURL = "KFS%205_0_2%20Test-favorites.htm";
